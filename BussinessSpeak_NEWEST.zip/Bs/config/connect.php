<?php

$connect = [
    'host' => 'localhost',
    'database' => 'nauka angielskiego',
    'user' => 'root',
    'password' => ''
];


?>