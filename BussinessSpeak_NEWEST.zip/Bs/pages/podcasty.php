


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bussiness Speak - PODCASTY</title>
	<link rel="stylesheet" type="text/css" href="../styles/style.css">
</head>
<body>

	<header>
  <div class="logo">
    <a href='../index.php'><img src="../img/logo.png" alt="awatar"></a>
  </div>

  <nav>
  	<ul>
         <li><a href="../index.php">Strona Główna</a></li>
      <li><a href="../pages/forum.php">Forum</a></li>
         <div class="dropdown">

      <li><a href="#">Zasoby</a></li>
       <div id="mini-menu">
  <a href="../pages/podcasty.php">Podcasty</a>
  <a href="../pages/plikidopobrania.php">Pliki do pobrania</a>
  <a href="../pages/slowniczek.php">Słowniczek</a>
  <a href="../pages/fiszki.php">Fiszki</a>
  <a href="../pages/podcasty.php">Gry i zabawy</a>
</div>
    </div>
  </ul>
      <a href='../pages/panel_usera.php'> <img src="../img/awatar.png" alt="Avatar"></a>
       <a href='panelogowania.php'> <button>Zaloguj się</button> </a>
       <a href='panelrejestracji.php'> <button>Zarejestruj się</button></a>

  </nav>
</header>
	<h2 style='text-align: center; padding:20px;'>PODCASTY</h2>
  <div class='podcasts'>

      <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie! Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div>
 <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div>
 <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div>
 <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div>

 <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div> <div class='podcastCont'>
        <h2>Jak się uczyć - N.N </h2>
        <p>Poznaj techniki nauki już dziś - odsłuchaj ten podcast jednego z najlepszych mentorów na świecie!</p>
         <audio controls>
  <source src="../audio/horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio> 
      </div>


  </div>


</body>
</html>