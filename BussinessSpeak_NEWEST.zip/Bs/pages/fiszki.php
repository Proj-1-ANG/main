<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projekt - Fiszki</title>
    <link rel="stylesheet" type="text/css" href="../styles/stylefiszki.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <!-- sekcja 1 -->
    <section id="section1">
        <p style="text-align: justify">technik informatyk/technik programista - Web design and programming languages</p>
        
            <button class="mainmenu"><a href="#">
            <i class="fa-solid fa-graduation-cap" style="color: blue"></i>
            Ucz się</a>
            </button>
        
       
            <button class="mainmenu"><a href="#">
                <i class="fa-solid fa-file-lines" style="color: blue"></i>
                Test</a></button>
       
        
        <div id="undermaindiv">
            <button id="volume">
            <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
        </button>
        <button id="favorite">
                    <i class="fa-solid fa-star" style="color: #2e2e2e"></i>
                </button>
            <div id="maindiv">
                <!-- TODO: dwa przyciski (jeden glosnik do odczytania glosowego, drugi gwiazdka do favorite)-->
                
                
                polski
            </div>
            <div id="bottombuttons">
                <button id="play" class="sidebyside">
                    <i class="fa-solid fa-play" style="color: #2e2e2e"></i>
                </button>
                <button id="shuffle" class="sidebyside">
                    <i class="fa-solid fa-shuffle" style="color: #2e2e2e"></i>
                </button>
                <button id="settings">
                    <i class="fa-solid fa-gear" style="color: #2e2e2e"></i>
                </button>
                <button id="fullscreen">
                    <i class="fa-solid fa-expand" style="color: #2e2e2e"></i>
                </button>
            </div>
        </div>
    </section>
    <!-- sekcja 2-->
    <section id="section2">
        <div id="undermaindiv2">
            <p>Liczba pojęć w tym zestawie </p>
            <header>
                  Wszystko
                  <i class="fa-solid fa-star" style="color: #2e2e2e"></i>
            </header>
            <b style="color: orange; font-weight: bold">Wciąż się uczę</b>
            <button style="color: #42d7f5; float: right;">
                <i class="fa-regular fa-star" style="color: #2e2e2e"></i>
                Zaznacz</button><br>
            Pojęcia, których wciąż się uczysz. Tak trzymaj!
            <div class="s2elements">
                web designer
                <p class="s2polishtexts">projektant stron internetowych</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                component
                <p class="s2polishtexts">część, składnik</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                render
                <p class="s2polishtexts">sprawiać, czynić, oddawać, przedstawiać</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                user-friendly
                <p class="s2polishtexts">przyjazny dla użytkownika</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                navigate a website
                <p class="s2polishtexts">poruszać się po stronie internetowej</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                findability
                <p class="s2polishtexts">łatwość znajdowania</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                encompass
                <p class="s2polishtexts">obejmować</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <br>
            <div class="s2elements">
                gaze point piot
                <p class="s2polishtexts">mapa ruchów oka</p>
                <button class="favorite2">
                    <i class="fa-solid fa-star" style="color: #fcba03"></i>
                </button>
                <button class="volume2">
                    <i class="fa-solid fa-volume-high" style="color: #2e2e2e"></i>
                </button>
            </div>
            <!-- <div class="tab">
                <i class="fa-solid fa-star" style="color: #2e2e2e"></i>
            </div> -->
        </div>
    </section>
    <script src="../scripts/script.js"></script>
</body>
</html>