<?php
if(session_status() == PHP_SESSION_DISABLED) session_start();

use App\class\Mysql;

require('../class/MysqlClass.php');

$db = new Mysql();
$db->connect();

if (isset($_COOKIE['authToken'])) { //logowanie za pomocą ciasteczka
    $query = $db->query("SELECT * FROM users WHERE auth_token = '".$_COOKIE['authToken']."';");
    if($db->num_rows($query)==1) {
        echo "Logowanie się powiodło ";
        $_SESSION['efekt'] = "zalogowano przez ciasteczko";
        header('Location:efekt.php');
        exit();
    } else {// gdy zawartość ciasteczka nie dopowiada żadnemu użytkownikowi
        // echo "Logowanie się  NIE powiodło ";
        // $_SESSION['efekt'] = "NIE zalogowano1";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bussiness Speak - Panel logowania</title>
	<link rel="stylesheet" type="text/css" href="../styles/style.css">
</head>
<body>

	<header>
  <div class="logo">
    <a href='../index.php'><img src="../img/logo.png" alt="awatar"></a>
  </div>

  <nav>
  	<ul>
         <li><a href="../index.php">Strona Główna</a></li>
      <li><a href="../pages/forum.php">Forum</a></li>
         <div class="dropdown">

      <li><a href="#">Zasoby</a></li>
       <div id="mini-menu">
  <a href="../pages/podcasty.php">Podcasty</a>
  <a href="../pages/plikidopobrania.php">Pliki do pobrania</a>
  <a href="../pages/slowniczek.php">Słowniczek</a>
  <a href="../pages/fiszki.php">Fiszki</a>
  <a href="../pages/podcasty.php">Gry i zabawy</a>
</div>
    </div>
  </ul>
      <a href='../pages/panel_usera.php'> <img src="../img/awatar.png" alt="Avatar"></a>
       <a href='panelogowania.php'> <button>Zaloguj się</button> </a>
       <a href='../pages/panelrejestracji.php'> <button>Zarejestruj się</button></a>

  </nav>
</header>
	<h2 style='text-align: center; padding:20px;'>PANEL LOGOWANIA</h2>


	<div class='formLogin'>
	<form method='POST' action='../scripts/logowanie.php'>
	<div class='imgContent'>
		<img src='../img/awatar.png' alt='awatar'/>
	</div>
	<div class='formContent'>
		<label for='email'>Email:</label>
		<input type='email' id='email' name='email' required/>
		<label for='haslo'>Haslo:</label>
		<input type='password' id='haslo' name='pass' required/>
		<input type="submit" name="send" value="ZALOGUJ"/>
		<label for='rememberme'>Zapamiętaj mnie:</label>
		<input type='checkbox' name='remember' id='rememberme'/>
	</div>
	</form>
	</div>
</body>
</html>