<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./styles/style.css">
    <title>BusinessSpeak - Efekt działania skryptu</title>
</head>

<body>
    <header> </header>
    <div class='panel'>
        <!-- plik testowy -->
        <h1>Gotowe elementy do testowania</h1>


        <!-- ukryj action w kodzie JS -->

        <h2>LOGOWANIE - kompletne</h2>
        <a href="./pages/panelogowania.php">Panel logowania</a>
        <!-- <form action="logowanie.php" method="POST">
    <input type="email" name="email" placeholder="email" required/>
    <input type="password" name="pass" placeholder="password" required/>
    <label><input type="checkbox" name="remember"/><span>Zapamiętaj hasło</span></label>
    <input type="submit" name="send" value="true" />
</form> -->

        <h2>REJESTARCJA - kompletne</h2>
        <a href="./pages/panelrejestracji.php">Panel Rejestracji</a>
        <!-- <form action="rejestracja.php" method="POST">
    <input type="text" name="login" placeholder="login" required/>
    <input type="email" name="email" placeholder="email" required/>
    <input type="password" name="pass" placeholder="password" required/>
    <input type="password" name="passConfirm" placeholder="password again" required/>
    <label><input type="checkbox" name="acceptRules" value="true" required/><span><a href="#">Zapoznałem się z regulaminem</a></span></label>
    <label><input type="checkbox" name="acceptRODO" value="true" required/><span>Akceptuję RODO</span></label>
    <input type="submit" name="send" />
</form> -->

    <h2>Fiszki - obracanie (polski/angielski) i zamiana textu na mowę</h2>
    <a href="./pages/fiszki.php">Panel Fiszki</a>
    </div>
</body>

</html>